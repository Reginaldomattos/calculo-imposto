package br.com.zup.calculo_imposto;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CalculoImpostoApplication {

	public static void main(String[] args) {
		SpringApplication.run(CalculoImpostoApplication.class, args);
	}

}
