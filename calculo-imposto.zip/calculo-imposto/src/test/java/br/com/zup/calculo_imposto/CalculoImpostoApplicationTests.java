package br.com.zup.calculo_imposto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CalculoImpostoApplicationTests {

	@Test
	void contextLoads() {
	}

}
